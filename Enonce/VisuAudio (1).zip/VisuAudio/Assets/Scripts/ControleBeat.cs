using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum EtatBeat { Offbeat = 0, Onbeat = 1 };
public class ControleBeat : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
